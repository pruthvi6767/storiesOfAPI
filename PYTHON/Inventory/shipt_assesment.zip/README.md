## 1 Script 
  
  python version is `3.7.3` with pip (~> 19.2.2)

  There are 3 script versions:
   - starwars.py = synchronous  
   - starwars_thread.py  = Multi-Threading 
   - starwars_async.py  = AsyncIO
    
  ```
    pip install urllib3 aiohttp && python starwars_async.py
  ```

## 2 OOP

   ```
      cd app/ && docker-compose up

    ```
    * esnure your port 8080 is open

